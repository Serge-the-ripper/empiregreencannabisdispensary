const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
require("dotenv").config();
const app = express();

app.use(express.json());

const pool = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10
});

/*
 * Health check
 */
app.get("/api/health", async (req, res) => {
    try {
        const [rows] = await pool.query("SELECT 1 AS database_test");

        res.json({
            status: "ok",
            database: rows[0].database_test === 1
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            status: "error",
            database: false
        });
    }
});

app.get("/api/products", async (req, res) => {
    try {
        const [products] = await pool.query(`
            SELECT
                id,
                slug,
                name,
                description,
                price,
                category,
                effects,
                is_featured,
                is_budtender_pick,
                is_new_arrival,
                is_deal,
                product_date,
                brand,
                product_type,
                weight,
                thc,
                cbd,
                image_url,
                available
            FROM products
            ORDER BY id ASC
        `);

        res.json(products);
    } catch (error) {
        console.error("Products API error:", error);
        res.status(500).json({
            error: "Failed to retrieve products"
        });
    }
});
/*
 * Get one product
 */
app.get("/api/products/:id", async (req, res) => {
    try {
        const [products] = await pool.query(
            "SELECT * FROM products WHERE id = ?",
            [req.params.id]
        );

        if (products.length === 0) {
            return res.status(404).json({
                error: "Product not found"
            });
        }

        res.json(products[0]);
    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "Failed to retrieve product"
        });
    }
});
app.get("/api/products/slug/:slug", async (req, res) => {
    try {
        const [products] = await pool.query(
            "SELECT * FROM products WHERE slug = ? LIMIT 1",
            [req.params.slug]
        );

        if (products.length === 0) {
            return res.status(404).json({
                error: "Product not found"
            });
        }

        res.json(products[0]);
    } catch (error) {
        console.error("Product slug API error:", error);
        res.status(500).json({
            error: "Failed to retrieve product"
        });
    }
});
/*
 * Create a product
 */
app.post("/api/products", async (req, res) => {
    try {
        const {
            name,
            description,
            price,
            category,
            brand,
            product_type,
            weight,
            thc,
            cbd,
            image_url,
            available
        } = req.body;

        if (!name) {
            return res.status(400).json({
                error: "Product name is required"
            });
        }

        const [result] = await pool.query(
            `INSERT INTO products
            (name, description, price, category, brand, product_type,
             weight, thc, cbd, image_url, available)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                name,
                description || null,
                price || null,
                category || null,
                brand || null,
                product_type || null,
                weight || null,
                thc || null,
                cbd || null,
                image_url || null,
                available ?? true
            ]
        );

        res.status(201).json({
            message: "Product created",
            id: result.insertId
        });
    } catch (error) {
        console.error(error);

        res.status(500).json({
            error: "Failed to create product"
        });
    }
});

/*
 * Serve the Empire Green frontend
 */

app.post("/api/orders", async (req, res) => {
    const connection = await pool.getConnection();

    try {
        const {
            customer_name,
            customer_email,
            customer_phone,
            fulfillment_type,
            delivery_address,
            delivery_city,
            delivery_state,
            delivery_zip,
            delivery_neighborhood,
            payment_method,
            notes,
            items
        } = req.body;

        if (!customer_name || !customer_phone || !customer_email) {
            return res.status(400).json({
                error: "Name, phone, and email are required"
            });
        }

        if (!["delivery", "pickup"].includes(fulfillment_type)) {
            return res.status(400).json({
                error: "Invalid fulfillment type"
            });
        }

        if (!Array.isArray(items) || items.length === 0) {
            return res.status(400).json({
                error: "Order must contain at least one item"
            });
        }

        await connection.beginTransaction();

        let subtotal = 0;
        const verifiedItems = [];

        for (const item of items) {
            const productId = Number(item.product_id);
            const productName = String(item.product_name || "").trim();
            const quantity = Number(item.quantity);

            if (!Number.isInteger(quantity) || quantity < 1) {
                throw new Error("Invalid order quantity");
            }

            let products;

            if (Number.isInteger(productId) && productId > 0) {
                [products] = await connection.query(
                    `SELECT id, name, price, weight, available
                     FROM products
                     WHERE id = ?
                     LIMIT 1`,
                    [productId]
                );
            } else if (productName) {
                [products] = await connection.query(
                    `SELECT id, name, price, weight, available
                     FROM products
                     WHERE name = ?
                     LIMIT 1`,
                    [productName]
                );
            } else {
                throw new Error("Order item is missing a valid product ID and product name");
            }

            if (products.length === 0) {
                throw new Error(
                    productName
                        ? `Product "${productName}" not found`
                        : `Product ${productId} not found`
                );
            }

            const product = products[0];

            if (!product.available) {
                throw new Error(`${product.name} is currently unavailable`);
            }

            const unitPrice = Number(product.price);
            const lineTotal = unitPrice * quantity;

            subtotal += lineTotal;

            verifiedItems.push({
                product_id: product.id,
                product_name: product.name,
                variant: item.variant || product.weight || null,
                quantity,
                unit_price: unitPrice,
                line_total: lineTotal
            });
        }

        const deliveryFee = 0;
        const total = subtotal + deliveryFee;

        const orderNumber =
            "EG-" +
            Date.now().toString(36).toUpperCase() +
            "-" +
            Math.floor(Math.random() * 900 + 100);

        const [orderResult] = await connection.query(
            `INSERT INTO orders (
                order_number,
                customer_name,
                customer_email,
                customer_phone,
                fulfillment_type,
                delivery_address,
                delivery_city,
                delivery_state,
                delivery_zip,
                delivery_neighborhood,
                payment_method,
                subtotal,
                delivery_fee,
                total,
                status,
                notes
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
            [
                orderNumber,
                customer_name,
                customer_email,
                customer_phone,
                fulfillment_type,
                delivery_address || null,
                delivery_city || null,
                delivery_state || null,
                delivery_zip || null,
                delivery_neighborhood || null,
                payment_method || null,
                subtotal.toFixed(2),
                deliveryFee.toFixed(2),
                total.toFixed(2),
                notes || null
            ]
        );

        for (const item of verifiedItems) {
            await connection.query(
                `INSERT INTO order_items (
                    order_id,
                    product_id,
                    product_name,
                    variant,
                    quantity,
                    unit_price,
                    line_total
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [
                    orderResult.insertId,
                    item.product_id,
                    item.product_name,
                    item.variant,
                    item.quantity,
                    item.unit_price.toFixed(2),
                    item.line_total.toFixed(2)
                ]
            );
        }

        await connection.commit();

        res.status(201).json({
            success: true,
            order_id: orderResult.insertId,
            order_number: orderNumber,
            subtotal: Number(subtotal.toFixed(2)),
            delivery_fee: deliveryFee,
            total: Number(total.toFixed(2)),
            status: "pending"
        });

    } catch (error) {
        await connection.rollback();

        console.error("Create order API error:", error);

        res.status(400).json({
            error: error.message || "Failed to create order"
        });
    } finally {
        connection.release();
    }
});

app.get("/api/orders/:orderNumber", async (req, res) => {
    try {
        const [orders] = await pool.query(
            `SELECT
                id,
                order_number,
                customer_name,
                customer_email,
                customer_phone,
                fulfillment_type,
                delivery_address,
                delivery_city,
                delivery_state,
                delivery_zip,
                delivery_neighborhood,
                payment_method,
                subtotal,
                delivery_fee,
                total,
                status,
                notes,
                created_at,
                updated_at
             FROM orders
             WHERE order_number = ?
             LIMIT 1`,
            [req.params.orderNumber]
        );

        if (orders.length === 0) {
            return res.status(404).json({
                error: "Order not found"
            });
        }

        const order = orders[0];

        const [items] = await pool.query(
            `SELECT
                product_id,
                product_name,
                variant,
                quantity,
                unit_price,
                line_total
             FROM order_items
             WHERE order_id = ?
             ORDER BY id ASC`,
            [order.id]
        );

        res.json({
            ...order,
            items
        });

    } catch (error) {
        console.error("Get order API error:", error);

        res.status(500).json({
            error: "Failed to retrieve order"
        });
    }
});

// Get order by order number



// Keep admin APIs disabled by default until admin authentication is configured.
app.use("/api/admin", (req, res, next) => {
    if (process.env.ADMIN_API_ENABLED === "true") return next();
    return res.status(404).json({ error: "Not found" });
});

// Admin: list orders
app.get("/api/admin/orders", async (req, res) => {
    try {
        const [orders] = await pool.query(
            `SELECT
                id,
                order_number,
                customer_name,
                customer_email,
                customer_phone,
                fulfillment_type,
                delivery_address,
                delivery_city,
                delivery_state,
                delivery_zip,
                subtotal,
                delivery_fee,
                total,
                status,
                created_at,
                updated_at
             FROM orders
             ORDER BY created_at DESC`
        );

        res.json(orders);
    } catch (error) {
        console.error("Admin orders error:", error);
        res.status(500).json({ error: "Failed to retrieve orders" });
    }
});


// Admin: update order status
app.patch("/api/admin/orders/:id/status", async (req, res) => {
    try {
        const allowedStatuses = [
            "pending",
            "confirmed",
            "preparing",
            "ready",
            "out_for_delivery",
            "completed",
            "cancelled"
        ];

        const { status } = req.body;

        if (!allowedStatuses.includes(status)) {
            return res.status(400).json({
                error: "Invalid order status"
            });
        }

        const [result] = await pool.query(
            `UPDATE orders
             SET status = ?
             WHERE id = ?`,
            [status, req.params.id]
        );

        if (!result.affectedRows) {
            return res.status(404).json({
                error: "Order not found"
            });
        }

        res.json({
            success: true,
            status
        });
    } catch (error) {
        console.error("Update order status error:", error);
        res.status(500).json({
            error: "Failed to update order status"
        });
    }
});


// Admin: list products
app.get("/api/admin/products", async (req, res) => {
    try {
        const [products] = await pool.query(
            `SELECT
                id,
                slug,
                name,
                price,
                category,
                brand,
                weight,
                available,
                is_featured,
                is_budtender_pick,
                is_new_arrival,
                is_deal
             FROM products
             ORDER BY id ASC`
        );

        res.json(products);
    } catch (error) {
        console.error("Admin products error:", error);
        res.status(500).json({
            error: "Failed to retrieve products"
        });
    }
});


// Admin: update product
app.patch("/api/admin/products/:id", async (req, res) => {
    try {
        const {
            price,
            available,
            is_featured,
            is_budtender_pick,
            is_new_arrival,
            is_deal
        } = req.body;

        const [result] = await pool.query(
            `UPDATE products
             SET
                price = COALESCE(?, price),
                available = COALESCE(?, available),
                is_featured = COALESCE(?, is_featured),
                is_budtender_pick = COALESCE(?, is_budtender_pick),
                is_new_arrival = COALESCE(?, is_new_arrival),
                is_deal = COALESCE(?, is_deal)
             WHERE id = ?`,
            [
                price ?? null,
                available ?? null,
                is_featured ?? null,
                is_budtender_pick ?? null,
                is_new_arrival ?? null,
                is_deal ?? null,
                req.params.id
            ]
        );

        if (!result.affectedRows) {
            return res.status(404).json({
                error: "Product not found"
            });
        }

        res.json({
            success: true
        });
    } catch (error) {
        console.error("Admin product update error:", error);
        res.status(500).json({
            error: "Failed to update product"
        });
    }
});
const frontendPath = path.join(__dirname, "public");

app.use(express.static(frontendPath));

const PORT = Number(process.env.PORT) || 3000;

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Empire Green app listening on port ${PORT}`);
});
