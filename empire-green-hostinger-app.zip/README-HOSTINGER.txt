Empire Green — Hostinger Web App package

This ZIP combines the current frontend with the working Express/MySQL API.

Hostinger setup:
1. Upload this ZIP in Web App → Upload your files.
2. Set these environment variables in Hostinger (do not upload a real .env file):
   DB_HOST = exact MySQL host shown in Hostinger hPanel
   DB_PORT = 3306 unless hPanel specifies otherwise
   DB_USER = production database username
   DB_PASSWORD = production database password
   DB_NAME = production database name
   NODE_ENV = production (if offered)
   ADMIN_API_ENABLED = false (leave false until admin authentication is configured)
3. Use npm start as startup command if Hostinger asks.
4. Deploy/restart and test /api/health, /api/products, and the home page.

The app uses Hostinger's PORT when available and serves frontend files from public/.
The .env.example file contains placeholders only. Old .before-* snapshots and local helper scripts are excluded. This package does not change existing websites or database contents.

Admin APIs are disabled by default through ADMIN_API_ENABLED=false. Keep this setting false until admin authentication is configured; setting it true exposes the existing admin endpoints without authentication and is not recommended for a public site.
